package Inheritance_day3;

public class Vowles {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
