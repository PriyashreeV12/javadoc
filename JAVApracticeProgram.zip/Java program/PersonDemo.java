package day2_programs;

public class PersonDemo {
	String name;
	String Address;

}
