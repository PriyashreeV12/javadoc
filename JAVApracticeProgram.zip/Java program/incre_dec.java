package day1_program;

public class incre_dec {

}
