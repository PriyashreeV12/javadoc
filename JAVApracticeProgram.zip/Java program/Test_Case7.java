package TestCases;
import java.util.Scanner;
public class Test_Case7 {

	public static void main(String[] args) {
		int n, m,N;
		Scanner s=new Scanner(System.in);
		System.out.println("   ");
	}

}
