package TestCases;

import java.util.Scanner;

public class TestCase_6 {

	public static void main(String[] args) {
	Scanner s=new Scanner(System.in);
	System.out.println("Enter:");
	String str=s.nextLine();
	char c[]=str.toCharArray();
	for (int i=0; i<c.length; i++)
	{
		int t=c [i+1]-'0';
		while(i-- >i) {
			System.out.println(c);
		}
		
	}
	

	}

}
